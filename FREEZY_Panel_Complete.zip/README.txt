FREEZY — COMPLETE PANEL + EGG SCANNER + AUTO-PICKUP
====================================================

This package intentionally contains ONLY the control panel, verified egg
scanner, egg filters/targeting, visualization and Auto-Pickup controller.
It does not create a map, eggs, pets, inventory, coins, rewards, spawns or
other game content.

FILES
-----
FREEZY.lua
  LocalScript. Install in StarterPlayer > StarterPlayerScripts.

FREEZYServer.lua
  Script. Install in ServerScriptService.

WHAT IS COMPLETE
----------------
- Draggable panel
- Resizable panel
- Close/reopen launcher
- Smooth open/close animation
- UI scale controls
- Mobile mouse/touch drag and resize
- Verified egg scanner
- Egg detection through CollectionService tag "Egg"
- Egg detection through IsEgg=true
- Egg detection through any EggId attribute
- Rarity detection/filtering
- Mutation detection/filtering
- Size detection/filtering
- Nearest target mode
- Rarity priority mode
- Largest/size priority mode with numeric + named size ranking
- Mutation priority mode
- Maximum distance filter
- Egg ESP
- Target ESP
- Distance labels
- Egg analyzer
- Session statistics and activity log
- Real Auto-Pickup modes: ONE, CONTINUOUS and QUEUE
- Auto-Pickup single-worker protection (prevents overlapping jobs)
- Stop All cancellation
- Prompt availability validation
- Server-side target validation
- Server-side start-position saving/restoration
- Pickup verification through observable existing game state

EGG DATA RECOGNITION
--------------------
An existing object is considered a verified egg when it has at least one:
  - CollectionService tag: Egg
  - Attribute: IsEgg = true
  - Attribute: EggId = <anything>

Optional attributes:
  Rarity / EggRarity / rarity
  Mutation / EggMutation / mutation
  Size / EggSize / size
  Available / Availability / IsAvailable

AUTO-PICKUP
-----------
Auto-Pickup is designed for an existing game that already uses a
ProximityPrompt for the egg interaction.

Flow:
  scan -> filter -> select -> server validates -> move near prompt ->
  normal ProximityPrompt input -> server verifies observable pickup state ->
  optionally return to starting position

The existing game's own pickup handler remains responsible for granting the
actual reward. FREEZY does not fabricate rewards or call a private reward API.

QUEUE MODE
----------
QUEUE is a real queue. A scan builds a list of all currently matching eggs,
and the worker processes one target at a time. It will not overlap requests.

IMPORTANT INTEGRATION NOTE
--------------------------
The panel does not need a map or a game database. It reads the existing
objects in the place. If the existing game does not mark its eggs using the
three supported verification methods above, add those markers to the game's
own egg objects. If its pickup system does not use ProximityPrompt, the
pickup adapter must be connected to that game's own server-authoritative
interaction API.
